DROP TABLE marathon;
