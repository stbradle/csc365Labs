-- Griffin Aswegan (gaswegan), Steven Bradley (stbradle)
DROP TABLE marathon;
