-- Griffin Aswegan (gaswegan), Steven Bradley (stbradle)
DROP TABLE campuses;
DROP TABLE fees;
DROP TABLE degrees;
DROP TABLE discEnroll;
DROP TABLE disciplines;
DROP TABLE enrollments;
DROP TABLE faculty;
