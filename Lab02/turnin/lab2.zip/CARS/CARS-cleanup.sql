-- Griffin Aswegan
-- Deletes all of the tables associated with the Cars dataset
--    (Continents, Countries, ModelList, CarData, CarMakers, and CarNames)

DROP TABLE CarData;
DROP TABLE CarNames;
DROP TABLE ModelList;
DROP TABLE CarMakers;
DROP TABLE Countries;
DROP TABLE Continents;
