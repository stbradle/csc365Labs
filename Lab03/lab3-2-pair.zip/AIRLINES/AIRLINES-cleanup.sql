-- Griffin Aswegan (gaswegan)
-- Professor E. Buckalew, CSC 365
-- October 8th, 2018
-- AIRLINES-cleanup.sql - removes "Airports", "Airlines", and "Flights" tables
--    from the database

DROP TABLE Flights;
DROP TABLE Airports;
DROP TABLE Airlines;
