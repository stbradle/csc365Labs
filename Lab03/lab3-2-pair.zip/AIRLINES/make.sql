source AIRLINES-cleanup.sql
source AIRLINES-setup.sql

source AIRLINES-build-airlines.sql
source AIRLINES-build-airports100.sql
source AIRLINES-build-flights.sql
