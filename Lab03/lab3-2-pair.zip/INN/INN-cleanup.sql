-- Griffin Aswegan (gaswegan)
-- Deletes the Rooms and Reservations tables

DROP TABLE Reservations;
DROP TABLE Rooms;
